﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class FallingDeath : MonoBehaviour
{
    public GameObject player;

    // Threshold value for player death
    public float fallThreshold = -10f;

    public string gameOverSceneName = "GameOver";

    void Update()
    {
        // Check if the player has fallen below the threshold
        if (player.transform.position.y < fallThreshold)
        {
            // Maze lvl back to zero
            GameManager.currentMazeLevel = 0;
            // Player has fallen, change scene to "GameOver"
            SceneManager.LoadScene(gameOverSceneName);

            // Destroy the play whispers
            GameObject whisperSource = GameObject.Find("WhisperSource");
            Destroy(whisperSource);
        }
    }
}