﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Pickup : MonoBehaviour {

	public float Speed = 1f;


	// Use this for initialization
	void Start () {


		StartCoroutine(moveUpandDown());
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.Rotate(0, 5f, 0, Space.World);

    }

	IEnumerator moveUpandDown()
	{
		while (true)
		{
            yield return new WaitForSeconds(2f);
            transform.Translate(Vector3.up * Speed, Space.World);
            Debug.Log("Moved up");

            yield return new WaitForSeconds(2f);
            transform.Translate(Vector3.down * Speed, Space.World);
            Debug.Log("Moved Down");
        }


    }
}
