﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class UpdateText : MonoBehaviour
{
    // Reference to the Text component
    public Text mazeLevelText;

    void Start()
    {

        mazeLevelText = GetComponent<Text>();
        // Update the Text from GameManager
        UpdateMazeLevelText();
    }

    public void UpdateMazeLevelText()
    {
        if (mazeLevelText != null)
        {
            // Update the Text with the current maze level
            mazeLevelText.text = "Maze Level: " + GameManager.currentMazeLevel.ToString();

        }
    }
}