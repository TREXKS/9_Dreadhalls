﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    // Static variable for current maze level
    public static int currentMazeLevel = 0;

    // reset level to zero
    public static void ResetMazeLevel()
    {
        currentMazeLevel = 0;
    }
}